from django.contrib import admin

from orders.models import Person
from orders.models import Order

# Register your models here.

admin.site.register(Person)
admin.site.register(Order)