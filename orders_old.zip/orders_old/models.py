

#https://betterprogramming.pub/partitioning-in-django-postgresql-d7ebbe8f9c2b
#https://pganalyze.com/blog/postgresql-partitioning-django

#python manage.py makemigrations --empty orders --name orders

from django.db import models
from psqlextra.types import PostgresPartitioningMethod
from psqlextra.models import PostgresPartitionedModel

class Person(PostgresPartitionedModel):
    class PartitioningMeta:
        method = PostgresPartitioningMethod.RANGE
        key = ["birth_date"]
    
    full_name = models.TextField()
    last_name = models.TextField(blank=True,null=True)
    birth_date = models.DateField()

from django.db import models
from psqlextra.models import PostgresPartitionedModel

class Order(PostgresPartitionedModel):
    name = models.TextField()
    # created = models.DateTimeField(auto_now_add=True)
    created = models.DateTimeField()

    class PartitioningMeta:
        method = PostgresPartitioningMethod.RANGE
        key = ["created"]

